# Sookta REBA Logic Evidence Package

Generated: 2026-06-03T12:14:23
Source comparison workbook: docs/Sookta_REBA_Logic_Before_After_Comparison.xlsx

This zip intentionally excludes the comparison workbook itself and includes only the files listed under Evidence and Source Paths as supporting evidence.

| Item | Path in repo | Size bytes | SHA256 | Note |
|---|---|---:|---|---|
| Training dataset workbook | `docs/Sookta_Research_Training_Dataset_REBA_ISO11228.xlsx` | 258635 | `6b78f17a76c19df5649baa14ad031a1d9d5c544528404669fdeea0af17461931` | source staging workbook |
| Training log | `docs/ml-training-run-20260603.md` | 10821 | `c6a86acded8d7fcc67cc71384d52a12349b1ba0045d7656315ce8b51c517bad4` | full metrics and verification |
| Logistic JSON | `assets/models/logistic_weights.json` | 10231 | `de629d046f451d9e84d8a51ff6d79523e1e211e793bc04bf7e3550edfd4e8fbb` | reba-iso-document-guided-logistic-2026-06-03 |
| XGBoost ONNX | `assets/models/xgboost_model.onnx` | 40098 | `b4b326b97fb365abe28d82e7cc085e41463a31b218f915c036f270e154c39a1d` | reba-iso-xgboost-onnx-2026-06-03 |
| XGBoost metadata | `assets/models/xgboost_model_metadata.json` | 3134 | `193dcadbc0b093120335da2a57c26d40cd9a02a79b4b1140e01bc8885627a01b` | metrics + feature names |
| Manifest | `assets/models/model_artifact_manifest.json` | 3306 | `cea11bc4439d89db12608e23729c96f09d60e332597604d18ed488ed0eca8e7f` | 2026-06-03 |
